<div align="center">
<img src="https://media1.giphy.com/media/LZmMH7lmHeNFe/giphy.gif?cid=ecf05e47dhlhvvz45tr6aoqzucvg06gelfxgkbhiiyrlvfqg&rid=giphy.gif" alt="Botto-re" width="600" />
 
 
 ## PIMBINHA <img src="https://media4.giphy.com/media/ZCh1xMxOh5a3S/giphy.gif" width="60px">
</div>



# MADE IN ExTRUPÍCIO <img src="https://media0.giphy.com/media/fVc6G5zbFwxo2YGXIP/giphy.gif
" width="60px">

```
## ATTENTION
## This project was carried out using the version of:

```bash
> git clone https://github.com/HasamiAini/Bot_Takagisan.git
```
## <"Thank you very much for providing width ="50px"> <img src="https://media1.giphy.com/media/Uv7jgxwTFaTGWlaQcR/giphy.gif" width="50px">

### FERRAMENTAS <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Prepare as ferramentas e materiais.
`` `bash
> 2 telefones celulares (1 para executar SC, 1 para ler o código QR sis)
> rede de internet rápida, cota +
> armazenamento adequado
> aplicativo whatsapp
> aplicativo termux
> café + cigarros KKKK;-;
```
INSTALAÇÃO:

> Se você não tiver o APK Termux, baixe-o na Playstore
> entre no apk termux e digite abaixo!
> termux-setup-storage
> pkg install git && pkg install tesseract && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/viictorxz/ExTRUP-CIO
> cd d4rk
> npm i -g cwebp && npm i node-tesseract-ocr && npm i -g ytdl && npm i  && npm i got && node index js
> Basta escanear o código qr e ... pronto




| ADESIVOS       |                RECURSOS           |
| :-----------:  |:--------------------------------:|
|       ✅       | Enviar foto com legenda          |
|       ✅       | Responda com uma foto            |
|       ✅       | Enviar vídeo ou GIF com legenda  |


| DOWNLOAD       |                     FUNÇÕES                   |
| :------------: |:---------------------------------------------:|
|       ✅        |   Download do YouTube mp3/mp4                |
|       ✅        |   Download do Instagram Video/Image          |
|       ✅        |   Download do Facebook Video                 |

| ECCHI DES NECESSÁRIO|                FUNÇÕES                   |
| :------------:   | :-----------------------------------------: |
|       ✅        |   Conteúdo 18+                                |
|       ✅        |   Doujin aleatório                            |
|       ✅        |   Obtenha uma imagem de Waifu aleatória       |
|       ✅        |   Obtenha uma imagem de Yuri  aleatória       |
|       ✅        |   Obtenha uma imagem de Yaoi  aleatória       |
|       ✅        |   Obtenha uma imagem de Loli  aleatória       |


|    OUTROS      |                      FUNÇÕES                  |
| :------------: | :-------------------------------------------: |
|       ✅        |   Meme aleatório                              |
|       ✅        |   Texto com voz                               |
|       ✅        |   Citações aleatórias                         |
|       ✅        |   Wikipedia                                   |
|       ✅        |   Buscador de Animes                          |
|      And         |   Others...                                   |


| COISAS DO GRUPO |                    FUNÇÕES                   |
| :------------:  | :-------------------------------------------:|
|       ✅        |   Promova o usuário             |
|       ✅        |   Rebaixar usuário              |
|       ✅        |   Banir usuário                 | 
|       ✅        |   Adcionar usuário              |
|       ✅        |   Mencionar todo mundo          |
|       ✅        |   Obter link do grupo           |
|       ✅        |   Lista de ADMs                 |
|       ✅        |   Banir todo mundo              |


<img src="https://media0.giphy.com/media/GYtblmdLnemlO/giphy.gif?cid=ecf05e47gyt1zjo9gnxo16ragtrl1sk84b1ejukzluou8ay1&rid=giphy.gif" alt="Anime" width="600" />